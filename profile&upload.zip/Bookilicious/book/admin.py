from django.contrib import admin
from book import models

# Register your models here.
admin.site.register(models.Book)