import re
from django import http
from django.shortcuts import render,HttpResponse
from book.models import Book
from .form import DocumentForm
from django.core.files.storage import default_storage

# Create your views here.
def profile(request):
    return render(request,'profile.html')

def form(request):
    context = {'Success':False}
    if request.method =="POST":
        title=request.POST['title']
        author=request.POST['Author']
        genre=request.POST['Genre']
        desc=request.POST['desc']
        docfile=request.POST['file']
        bform=Book(btitle=title,bauthor=author,bgenre=genre,bpreface=desc,bfile=docfile)
        bform.save()
        print(title,desc,author,genre,desc)
        context = {'Success':True }
    return render(request,'form.html',context)

def uploads(request):
    allBooks = Book.objects.all()
    context = { 'Books' : allBooks }
    #for con in allBooks:
       # print(con.Title)
    return render(request,'uploads.html',context)
