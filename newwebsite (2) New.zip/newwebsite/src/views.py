from django.shortcuts import render

# Create your views here.

from django.shortcuts import redirect, render
from django.contrib.auth.models import User,auth


# Create your views here.
def mohit(request):

    return render(request,'index_R.html')
